import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput, Button, FlatList, TouchableOpacity } from 'react-native';
import { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native'; 
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

export default function App() { 
  return (
    <NavigationContainer> 
      <Stack.Navigator>
        <Stack.Screen name="Home" component={MainScreen} />
        <Stack.Screen name="ViewDetails" component={ViewDetails} />
        <Stack.Screen name="SecondPage" component={SecondPage} />
      </Stack.Navigator>      
    </NavigationContainer> 
  );
}

// Define the type for navigation prop
type MainScreenProps = {
  navigation: {
    navigate: (screen: string, params?: object) => void;
  };
};

// Meal type
type Meal = {
  id: number;
  name: string;
  price: number;
};

// MainScreen component
function MainScreen({ navigation }: MainScreenProps) { 
  const [meals, setMeals] = useState<Meal[]>([]);
  const [mealName, setMealName] = useState<string>(''); 
  const [mealPrice, setMealPrice] = useState<string>(''); 
  const [Name, setName] = useState('');
  const [Surname, setSurname] = useState('');

  const addMeal = () => {
    if (mealName && mealPrice) {
      const newMeal: Meal = {
        id: meals.length + 1,
        name: mealName,
        price: parseFloat(mealPrice),
      };
      setMeals([...meals, newMeal]);
      setMealName('');
      setMealPrice('');
    }
  };

  const editMeal = (id: number) => {
    const mealToEdit = meals.find(meal => meal.id === id);
    if (mealToEdit) {
      navigation.navigate('ViewDetails', { meal: mealToEdit, meals, setMeals });
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput 
        placeholder="Meal Name" 
        onChangeText={setMealName} 
        value={mealName}
        style={styles.input} 
      />
      <TextInput 
        placeholder="Meal Price" 
        onChangeText={setMealPrice} 
        value={mealPrice}
        keyboardType="numeric"
        style={styles.input} 
      />
      
      <Button 
        title='Add Meal'
        onPress={addMeal}
      />

      <Button 
        title='Next Page'
        onPress={() => {
          navigation.navigate('SecondPage', { meals });
        }}
      />

      <FlatList 
        data={meals}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => editMeal(item.id)}>
            <Text>{item.name}: ${item.price.toFixed(2)}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

// Define the type for route params
type SecondPageProps = {
  route: {
    params: {
      Name: string;
      Surname: string;
      meals: Meal[];  // Include meals in the params
    };
  };
};

// SecondPage component
function SecondPage({ route }: SecondPageProps) {
  const { Name, Surname, meals } = route.params;

  // Calculate subtotal
  const subtotal = meals.reduce((total, meal) => total + meal.price, 0);

  return (
    <View style={{ flex: 1, alignContent: 'center', justifyContent: 'center' }}> 
      <Text>Subtotal: ${subtotal.toFixed(2)}</Text>
      <Text>Name: {Name}</Text>
      <Text>Surname: {Surname}</Text>
    </View>
  );
}

// Define the type for ViewDetails props
type ViewDetailsProps = {
  route: {
    params: {
      meal: Meal;
      meals: Meal[];
      setMeals: (meals: Meal[]) => void;
    };
  };
};

// ViewDetails component
function ViewDetails({ route }: ViewDetailsProps) {
  const { meal, meals, setMeals } = route.params;
  const [mealName, setMealName] = useState<string>(meal.name);
  const [mealPrice, setMealPrice] = useState<string>(meal.price.toString());

  const saveMeal = () => {
    const updatedMeals = meals.map(m => 
      m.id === meal.id ? { ...m, name: mealName, price: parseFloat(mealPrice) } : m
    );
    setMeals(updatedMeals);
    // Optionally navigate back
  };

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <TextInput 
        placeholder="Meal Name" 
        onChangeText={setMealName} 
        value={mealName}
        style={styles.input} 
      />
      <TextInput 
        placeholder="Meal Price" 
        onChangeText={setMealPrice} 
        value={mealPrice}
        keyboardType="numeric"
        style={styles.input} 
      />
      <Button title="Save Meal" onPress={saveMeal} />
      <Text>Current Meal: {meal.name} - ${meal.price.toFixed(2)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  }
});






